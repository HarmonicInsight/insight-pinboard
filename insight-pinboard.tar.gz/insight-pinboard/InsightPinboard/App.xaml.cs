using System.Windows;

namespace InsightPinboard;

public partial class App : Application
{
}
